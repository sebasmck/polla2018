<?php $__env->startSection('pagetitle'); ?>
    Ranking
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-md-12 title_polla">
                <img src="<?php echo e(asset('img/logo.png')); ?>" style="height: 150px;">
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-md-8">
                                <a style="float: left; margin-right: 15px;" href="<?php echo e(route('home')); ?>"><button class="btn btn-primary" id="close"> < </button></a>
                                <h4><?php echo e(__('Ranking')); ?> </h4>
                            </div>
                        </div>
                        
                        
                    </div>

                    <div class="card-body">
                         <div class="row">
                            <div class="col-md-12 table-responsive">
                                <table id="ranking" class="table table_pool">
                                        <thead>
                                            <tr>
                                                <th>Ranking</th>
                                                <th>Nickname</th>
                                                <th>Score</th>
                                                <th>Finalist</th>
                                                <th>Champion</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $polls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poll): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(Auth()->user()->id == $poll->id_User): ?>
                                            <tr style="border: solid 1px #004782; background-color: #ebe9ed;">
                                                <td><?php echo e($poll->ranking); ?>/<?php echo e($activepolls); ?></td>
                                                <td><a href="<?php echo e(route('adminprintpicks.show', $poll->iduser_poll)); ?>"><?php echo e($poll->poll_name); ?></a></td>
                                                <td><?php echo e($poll->score); ?></td>
                                                <td><?php echo e($poll->finalFinalist($poll->iduser_poll)); ?></td>
                                                <td><?php echo e($poll->finalWinner($poll->iduser_poll)); ?></td>
                                            </tr>
                                            <?php else: ?>
                                            <tr>
                                                <td><?php echo e($poll->ranking); ?>/<?php echo e($activepolls); ?></td>
                                                <td><a href="<?php echo e(route('adminprintpicks.show', $poll->iduser_poll)); ?>"><?php echo e($poll->poll_name); ?></a></td>
                                                <td><?php echo e($poll->score); ?></td>
                                                <td><?php echo e($poll->finalFinalist($poll->iduser_poll)); ?></td>
                                                <td><?php echo e($poll->finalWinner($poll->iduser_poll)); ?></td>
                                            </tr>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                </table> 
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
     </div>

<?php $__env->stopSection(); ?>


 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>



<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.js"> </script>
<script src="<?php echo e(URL::asset('js/app.js')); ?>"></script>
<script src="<?php echo e(URL::asset('scripts/countdown.js')); ?>"></script>
<?php echo $__env->make('admin.partials.js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script>
    $(document).ready(function(){
        // $('#ranking').DataTable();
        // $("#ranking").tablesorter({sortList: [[2,1], [1,1]]});
    });
</script>





<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>