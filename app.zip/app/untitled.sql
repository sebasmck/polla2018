CREATE DEFINER=`vksbgxbd_pollaworldcup`@`%` PROCEDURE `scores`()
BEGIN
  DECLARE cont_score INT;
  DECLARE bonus_16 INT;
  DECLARE bonus_Quarter INT;
  DECLARE bonus_Semi INT;
  DECLARE bonus_Final INT;
  
  DECLARE idpool INT;
  DECLARE score_pool INT;
  DECLARE findelbucle INTEGER DEFAULT 0;
  
  DECLARE cursor_score CURSOR FOR 
    SELECT iduser_poll, score FROM user_poll;
  
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET findelbucle=1;
  
  OPEN cursor_score;
  bucle: LOOP
    FETCH cursor_score INTO idpool,score_pool;
    IF findelbucle = 1 THEN
       LEAVE bucle;
    END IF;
  
	SET cont_score = 0;
	SET bonus_16 = 0;
	SET bonus_Quarter = 0;
	SET bonus_Semi = 0;
	SET bonus_Final = 0;
  	-- Puntos por grupos
  	-- GRUPO A
		-- MATCH 1
		SET @M := ( select CONCAT(M1A1, '-', M1A2) from `picks_group_a` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M1A1, '-', M1A2) from `picks_group_a` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;
		
        -- MATCH 2
		SET @M := ( select CONCAT(M2A3, '-', M2A4) from `picks_group_a` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M2A3, '-', M2A4) from `picks_group_a` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;
        
        -- MATCH 3
		SET @M := ( select CONCAT(M3A1, '-', M3A3) from `picks_group_a` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M3A1, '-', M3A3) from `picks_group_a` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		-- MATCH 4
		SET @M := ( select CONCAT(M4A4, '-', M4A2) from `picks_group_a` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M4A4, '-', M4A2) from `picks_group_a` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		-- MATCH 5
		SET @M := ( select CONCAT(M5A4, '-', M5A1) from `picks_group_a` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M5A4, '-', M5A1) from `picks_group_a` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		-- MATCH 6
		SET @M := ( select CONCAT(M6A2, '-', M6A3) from `picks_group_a` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M6A2, '-', M6A3) from `picks_group_a` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		-- GANADORES 
		SET @W1 := ( select id_winner_team from `clasificado` where `id_poll` =idpool and `id_fase` = 1);
		SET @W2 := ( select id_runnerup from `clasificado` where `id_poll` =idpool and `id_fase` = 1);
		SET @AW1 := ( select id_winner_team from `clasificado` where `id_poll` =504 and `id_fase` = 1);
		SET @AW2 := ( select id_runnerup from `clasificado` where `id_poll` =504 and `id_fase` = 1);

		IF @W1 = @AW1 THEN
			SET cont_score = cont_score +  1;
			SET bonus_16 =  bonus_16 + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		IF @W2 = @AW2 THEN
			SET cont_score = cont_score +  1;
			SET bonus_16 =  bonus_16 + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;
        
        IF @W2 = @AW1 THEN
			SET cont_score = cont_score +  1;
			SET bonus_16 =  bonus_16 + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		IF @W1 = @AW2 THEN
			SET cont_score = cont_score +  1;
			SET bonus_16 =  bonus_16 + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;


		-- GRUPO B
        -- MATCH 1
		SET @M := ( select CONCAT(M1B1, '-', M1B2) from `picks_group_b` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M1B1, '-', M1B2) from `picks_group_b` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;
		
        -- MATCH 2
		SET @M := ( select CONCAT(M2B3, '-', M2B4) from `picks_group_b` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M2B3, '-', M2B4) from `picks_group_b` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;
        
        -- MATCH 3
		SET @M := ( select CONCAT(M3B1, '-', M3B3) from `picks_group_b` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M3B1, '-', M3B3) from `picks_group_b` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		-- MATCH 4
		SET @M := ( select CONCAT(M4B4, '-', M4B2) from `picks_group_b` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M4B4, '-', M4B2) from `picks_group_b` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		-- MATCH 5
		SET @M := ( select CONCAT(M5B4, '-', M5B1) from `picks_group_b` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M5B4, '-', M5B1) from `picks_group_b` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		-- MATCH 6
		SET @M := ( select CONCAT(M6B2, '-', M6B3) from `picks_group_b` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M6B2, '-', M6B3) from `picks_group_b` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		-- GANADORES 
		SET @W1 := ( select id_winner_team from `clasificado` where `id_poll` =idpool and `id_fase` = 2);
		SET @W2 := ( select id_runnerup from `clasificado` where `id_poll` =idpool and `id_fase` = 2);
		SET @AW1 := ( select id_winner_team from `clasificado` where `id_poll` =504 and `id_fase` = 2);
		SET @AW2 := ( select id_runnerup from `clasificado` where `id_poll` =504 and `id_fase` = 2);

		IF @W1 = @AW1 THEN
			SET cont_score = cont_score +  1;
			SET bonus_16 =  bonus_16 + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		IF @W2 = @AW2 THEN
			SET cont_score = cont_score +  1;
			SET bonus_16 =  bonus_16 + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;
        
        IF @W2 = @AW1 THEN
			SET cont_score = cont_score +  1;
			SET bonus_16 =  bonus_16 + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		IF @W1 = @AW2 THEN
			SET cont_score = cont_score +  1;
			SET bonus_16 =  bonus_16 + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;
        


		-- GRUPO C
        -- MATCH 1
		SET @M := ( select CONCAT(M1C1, '-', M1C2) from `picks_group_c` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M1C1, '-', M1C2) from `picks_group_c` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;
		
        -- MATCH 2
		SET @M := ( select CONCAT(M2C3, '-', M2C4) from `picks_group_c` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M2C3, '-', M2C4) from `picks_group_c` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;
        
        -- MATCH 3
		SET @M := ( select CONCAT(M3C1, '-', M3C3) from `picks_group_c` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M3C1, '-', M3C3) from `picks_group_c` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		-- MATCH 4
		SET @M := ( select CONCAT(M4C4, '-', M4C2) from `picks_group_c` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M4C4, '-', M4C2) from `picks_group_c` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		-- MATCH 5
		SET @M := ( select CONCAT(M5C4, '-', M5C1) from `picks_group_c` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M5C4, '-', M5C1) from `picks_group_c` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		-- MATCH 6
		SET @M := ( select CONCAT(M6C2, '-', M6C3) from `picks_group_c` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M6C2, '-', M6C3) from `picks_group_c` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		-- GANADORES 
		SET @W1 := ( select id_winner_team from `clasificado` where `id_poll` =idpool and `id_fase` = 3);
		SET @W2 := ( select id_runnerup from `clasificado` where `id_poll` =idpool and `id_fase` = 3);
		SET @AW1 := ( select id_winner_team from `clasificado` where `id_poll` =504 and `id_fase` = 3);
		SET @AW2 := ( select id_runnerup from `clasificado` where `id_poll` =504 and `id_fase` = 3);

		IF @W1 = @AW1 THEN
			SET cont_score = cont_score +  1;
			SET bonus_16 =  bonus_16 + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		IF @W2 = @AW2 THEN
			SET cont_score = cont_score +  1;
			SET bonus_16 =  bonus_16 + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;
        
        IF @W2 = @AW1 THEN
			SET cont_score = cont_score +  1;
			SET bonus_16 =  bonus_16 + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		IF @W1 = @AW2 THEN
			SET cont_score = cont_score +  1;
			SET bonus_16 =  bonus_16 + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;


		-- GRUPO D
        -- MATCH 1
		SET @M := ( select CONCAT(M1D1, '-', M1D2) from `picks_group_d` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M1D1, '-', M1D2) from `picks_group_d` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;
		
        -- MATCH 2
		SET @M := ( select CONCAT(M2D3, '-', M2D4) from `picks_group_d` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M2D3, '-', M2D4) from `picks_group_d` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;
        
        -- MATCH 3
		SET @M := ( select CONCAT(M3D1, '-', M3D3) from `picks_group_d` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M3D1, '-', M3D3) from `picks_group_d` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		-- MATCH 4
		SET @M := ( select CONCAT(M4D4, '-', M4D2) from `picks_group_d` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M4D4, '-', M4D2) from `picks_group_d` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		-- MATCH 5
		SET @M := ( select CONCAT(M5D4, '-', M5D1) from `picks_group_d` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M5D4, '-', M5D1) from `picks_group_d` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		-- MATCH 6
		SET @M := ( select CONCAT(M6D2, '-', M6D3) from `picks_group_d` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M6D2, '-', M6D3) from `picks_group_d` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		-- GANADORES 
		SET @W1 := ( select id_winner_team from `clasificado` where `id_poll` =idpool and `id_fase` = 4);
		SET @W2 := ( select id_runnerup from `clasificado` where `id_poll` =idpool and `id_fase` = 4);
		SET @AW1 := ( select id_winner_team from `clasificado` where `id_poll` =504 and `id_fase` = 4);
		SET @AW2 := ( select id_runnerup from `clasificado` where `id_poll` =504 and `id_fase` = 4);

		IF @W1 = @AW1 THEN
			SET cont_score = cont_score +  1;
			SET bonus_16 =  bonus_16 + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		IF @W2 = @AW2 THEN
			SET cont_score = cont_score +  1;
			SET bonus_16 =  bonus_16 + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;
        
        IF @W2 = @AW1 THEN
			SET cont_score = cont_score +  1;
			SET bonus_16 =  bonus_16 + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		IF @W1 = @AW2 THEN
			SET cont_score = cont_score +  1;
			SET bonus_16 =  bonus_16 + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		-- GRUPO E
        -- MATCH 1
		SET @M := ( select CONCAT(M1E1, '-', M1E2) from `picks_group_e` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M1E1, '-', M1E2) from `picks_group_e` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;
		
        -- MATCH 2
		SET @M := ( select CONCAT(M2E3, '-', M2E4) from `picks_group_e` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M2E3, '-', M2E4) from `picks_group_e` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;
        
        -- MATCH 3
		SET @M := ( select CONCAT(M3E1, '-', M3E3) from `picks_group_e` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M3E1, '-', M3E3) from `picks_group_e` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		-- MATCH 4
		SET @M := ( select CONCAT(M4E4, '-', M4E2) from `picks_group_e` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M4E4, '-', M4E2) from `picks_group_e` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		-- MATCH 5
		SET @M := ( select CONCAT(M5E4, '-', M5E1) from `picks_group_e` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M5E4, '-', M5E1) from `picks_group_e` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		-- MATCH 6
		SET @M := ( select CONCAT(M6E2, '-', M6E3) from `picks_group_e` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M6E2, '-', M6E3) from `picks_group_e` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		-- GANADORES 
		SET @W1 := ( select id_winner_team from `clasificado` where `id_poll` =idpool and `id_fase` = 5);
		SET @W2 := ( select id_runnerup from `clasificado` where `id_poll` =idpool and `id_fase` = 5);
		SET @AW1 := ( select id_winner_team from `clasificado` where `id_poll` =504 and `id_fase` = 5);
		SET @AW2 := ( select id_runnerup from `clasificado` where `id_poll` =504 and `id_fase` = 5);

		IF @W1 = @AW1 THEN
			SET cont_score = cont_score +  1;
			SET bonus_16 =  bonus_16 + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		IF @W2 = @AW2 THEN
			SET cont_score = cont_score +  1;
			SET bonus_16 =  bonus_16 + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;
        
        IF @W2 = @AW1 THEN
			SET cont_score = cont_score +  1;
			SET bonus_16 =  bonus_16 + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		IF @W1 = @AW2 THEN
			SET cont_score = cont_score +  1;
			SET bonus_16 =  bonus_16 + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;


		-- GRUPO F
        -- MATCH 1
		SET @M := ( select CONCAT(M1F1, '-', M1F2) from `picks_group_f` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M1F1, '-', M1F2) from `picks_group_f` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;
		
        -- MATCH 2
		SET @M := ( select CONCAT(M2F3, '-', M2F4) from `picks_group_f` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M2F3, '-', M2F4) from `picks_group_f` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;
        
        -- MATCH 3
		SET @M := ( select CONCAT(M3F1, '-', M3F3) from `picks_group_f` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M3F1, '-', M3F3) from `picks_group_f` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		-- MATCH 4
		SET @M := ( select CONCAT(M4F4, '-', M4F2) from `picks_group_f` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M4F4, '-', M4F2) from `picks_group_f` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		-- MATCH 5
		SET @M := ( select CONCAT(M5F4, '-', M5F1) from `picks_group_f` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M5F4, '-', M5F1) from `picks_group_f` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		-- MATCH 6
		SET @M := ( select CONCAT(M6F2, '-', M6F3) from `picks_group_f` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M6F2, '-', M6F3) from `picks_group_f` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		-- GANADORES 
		SET @W1 := ( select id_winner_team from `clasificado` where `id_poll` =idpool and `id_fase` = 6);
		SET @W2 := ( select id_runnerup from `clasificado` where `id_poll` =idpool and `id_fase` = 6);
		SET @AW1 := ( select id_winner_team from `clasificado` where `id_poll` =504 and `id_fase` = 6);
		SET @AW2 := ( select id_runnerup from `clasificado` where `id_poll` =504 and `id_fase` = 6);

		IF @W1 = @AW1 THEN
			SET cont_score = cont_score +  1;
			SET bonus_16 =  bonus_16 + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		IF @W2 = @AW2 THEN
			SET cont_score = cont_score +  1;
			SET bonus_16 =  bonus_16 + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;
        
        IF @W2 = @AW1 THEN
			SET cont_score = cont_score +  1;
			SET bonus_16 =  bonus_16 + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		IF @W1 = @AW2 THEN
			SET cont_score = cont_score +  1;
			SET bonus_16 =  bonus_16 + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;


		-- GRUPO G
        -- MATCH 1
		SET @M := ( select CONCAT(M1G1, '-', M1G2) from `picks_group_g` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M1G1, '-', M1G2) from `picks_group_g` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;
		
        -- MATCH 2
		SET @M := ( select CONCAT(M2G3, '-', M2G4) from `picks_group_g` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M2G3, '-', M2G4) from `picks_group_g` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;
        
        -- MATCH 3
		SET @M := ( select CONCAT(M3G1, '-', M3G3) from `picks_group_g` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M3G1, '-', M3G3) from `picks_group_g` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		-- MATCH 4
		SET @M := ( select CONCAT(M4G4, '-', M4G2) from `picks_group_g` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M4G4, '-', M4G2) from `picks_group_g` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		-- MATCH 5
		SET @M := ( select CONCAT(M5G4, '-', M5G1) from `picks_group_g` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M5G4, '-', M5G1) from `picks_group_g` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		-- MATCH 6
		SET @M := ( select CONCAT(M6G2, '-', M6G3) from `picks_group_g` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M6G2, '-', M6G3) from `picks_group_g` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		-- GANADORES 
		SET @W1 := ( select id_winner_team from `clasificado` where `id_poll` =idpool and `id_fase` = 7);
		SET @W2 := ( select id_runnerup from `clasificado` where `id_poll` =idpool and `id_fase` = 7);
		SET @AW1 := ( select id_winner_team from `clasificado` where `id_poll` =504 and `id_fase` = 7);
		SET @AW2 := ( select id_runnerup from `clasificado` where `id_poll` =504 and `id_fase` = 7);

		IF @W1 = @AW1 THEN
			SET cont_score = cont_score +  1;
			SET bonus_16 =  bonus_16 + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		IF @W2 = @AW2 THEN
			SET cont_score = cont_score +  1;
			SET bonus_16 =  bonus_16 + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;
        
        IF @W2 = @AW1 THEN
			SET cont_score = cont_score +  1;
			SET bonus_16 =  bonus_16 + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		IF @W1 = @AW2 THEN
			SET cont_score = cont_score +  1;
			SET bonus_16 =  bonus_16 + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;


		-- GRUPO H
        -- MATCH 1
		SET @M := ( select CONCAT(M1H1, '-', M1H2) from `picks_group_h` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M1H1, '-', M1H2) from `picks_group_h` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;
		
        -- MATCH 2
		SET @M := ( select CONCAT(M2H3, '-', M2H4) from `picks_group_h` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M2H3, '-', M2H4) from `picks_group_h` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;
        
        -- MATCH 3
		SET @M := ( select CONCAT(M3H1, '-', M3H3) from `picks_group_h` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M3H1, '-', M3H3) from `picks_group_h` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		-- MATCH 4
		SET @M := ( select CONCAT(M4H4, '-', M4H2) from `picks_group_h` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M4H4, '-', M4H2) from `picks_group_h` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		-- MATCH 5
		SET @M := ( select CONCAT(M5H4, '-', M5H1) from `picks_group_h` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M5H4, '-', M5H1) from `picks_group_h` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		-- MATCH 6
		SET @M := ( select CONCAT(M6H2, '-', M6H3) from `picks_group_h` where `id_poll` =idpool);
		SET @AM := ( select CONCAT(M6H2, '-', M6H3) from `picks_group_h` where `id_poll` =504);
		
		IF @M = @AM THEN
			SET cont_score = cont_score +  2;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		-- GANADORES 
		SET @W1 := ( select id_winner_team from `clasificado` where `id_poll` =idpool and `id_fase` = 8);
		SET @W2 := ( select id_runnerup from `clasificado` where `id_poll` =idpool and `id_fase` = 8);
		SET @AW1 := ( select id_winner_team from `clasificado` where `id_poll` =504 and `id_fase` = 8);
		SET @AW2 := ( select id_runnerup from `clasificado` where `id_poll` =504 and `id_fase` = 8);

		IF @W1 = @AW1 THEN
			SET cont_score = cont_score +  1;
			SET bonus_16 =  bonus_16 + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		IF @W2 = @AW2 THEN
			SET cont_score = cont_score +  1;
			SET bonus_16 =  bonus_16 + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;
        
        IF @W2 = @AW1 THEN
			SET cont_score = cont_score +  1;
			SET bonus_16 =  bonus_16 + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		IF @W1 = @AW2 THEN
			SET cont_score = cont_score +  1;
			SET bonus_16 =  bonus_16 + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;


		-- BONUS 16 
		If bonus_16 = 16 THEN
			SET cont_score = cont_score +  4;
		END IF;


		-- Quarter-Final
		SET @Q1 := ( select quarter_1 from `second_stage` where `id_poll` =idpool);
		SET @Q2 := ( select quarter_2 from `second_stage` where `id_poll` =idpool);
		SET @D3 := ( select quarter_3 from `second_stage` where `id_poll` =idpool);
		SET @Q4 := ( select quarter_4 from `second_stage` where `id_poll` =idpool);
		SET @Q5 := ( select quarter_5 from `second_stage` where `id_poll` =idpool);
		SET @Q6 := ( select quarter_6 from `second_stage` where `id_poll` =idpool);
		SET @Q7 := ( select quarter_7 from `second_stage` where `id_poll` =idpool);
		SET @Q8 := ( select quarter_8 from `second_stage` where `id_poll` =idpool);
		SET @AQ1 := ( select quarter_1 from `second_stage` where `id_poll` =504);

		IF @Q1 = @AQ1 OR @Q2= @AQ1 OR @Q3= @AQ1 OR @Q4= @AQ1 OR @Q5 = @AQ1 OR @Q6= @AQ1 OR @Q7= @AQ1 OR @Q8= @AQ1  THEN
			SET cont_score = cont_score +  2;
			SET bonus_Quarter =  bonus_Quarter + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;
        

		SET @AQ2 := ( select quarter_2 from `second_stage` where `id_poll` =504);

		IF @Q1 = @AQ2 OR @Q2= @AQ2 OR @Q3= @AQ2 OR @Q4= @AQ2  OR @Q5 = @AQ2 OR @Q6= @AQ2 OR @Q7= @AQ2 OR @Q8= @AQ2 THEN
			SET cont_score = cont_score +  2;
			SET bonus_Quarter =  bonus_Quarter + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		
		SET @AQ3 := ( select quarter_3 from `second_stage` where `id_poll` =504);

		IF @Q1 = @AQ3 OR @Q2= @AQ3 OR @Q3= @AQ3 OR @Q4= @AQ3 OR @Q5 = @AQ3 OR @Q6= @AQ3 OR @Q7= @AQ3 OR @Q8= @AQ3  THEN
			SET cont_score = cont_score +  2;
			SET bonus_Quarter =  bonus_Quarter + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		
		SET @AQ4 := ( select quarter_4 from `second_stage` where `id_poll` =504);

		IF @Q1 = @AQ4 OR @Q2= @AQ4 OR @Q3= @AQ4 OR @Q4= @AQ4 OR @Q5 = @AQ4 OR @Q6= @AQ4 OR @Q7= @AQ4 OR @Q8= @AQ4 THEN
			SET cont_score = cont_score +  2;
			SET bonus_Quarter =  bonus_Quarter + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		
		SET @AQ5 := ( select quarter_5 from `second_stage` where `id_poll` =504);

		IF @Q1 = @AQ5 OR @Q2= @AQ5 OR @Q3= @AQ5 OR @Q4= @AQ5 OR @Q5 = @AQ5 OR @Q6= @AQ5 OR @Q7= @AQ5 OR @Q8= @AQ5 THEN
			SET cont_score = cont_score +  2;
			SET bonus_Quarter =  bonus_Quarter + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		
		SET @AQ6 := ( select quarter_6 from `second_stage` where `id_poll` =504);

		IF @Q1 = @AQ6 OR @Q2= @AQ6 OR @Q3= @AQ6 OR @Q4= @AQ6 OR @Q5 = @AQ6 OR @Q6= @AQ6 OR @Q7= @AQ6 OR @Q8= @AQ6 THEN
			SET cont_score = cont_score +  2;
			SET bonus_Quarter =  bonus_Quarter + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		
		SET @AQ7 := ( select quarter_7 from `second_stage` where `id_poll` =504);

		IF @Q1 = @AQ7 OR @Q2= @AQ7 OR @Q3= @AQ7 OR @Q4= @AQ7 OR @Q5 = @AQ7 OR @Q6= @AQ7 OR @Q7= @AQ7 OR @Q8= @AQ7 THEN
			SET cont_score = cont_score +  2;
			SET bonus_Quarter =  bonus_Quarter + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		
		SET @AQ8 := ( select quarter_8 from `second_stage` where `id_poll` =504);

		IF @Q1 = @AQ8 OR @Q2= @AQ8 OR @Q3= @AQ8 OR @Q4= @AQ8 OR @Q5 = @AQ8 OR @Q6= @AQ8 OR @Q7= @AQ8 OR @Q8= @AQ8 THEN
			SET cont_score = cont_score +  2;
			SET bonus_Quarter =  bonus_Quarter + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		-- BONUS Quarter 
		If bonus_Quarter = 8 THEN
			SET cont_score = cont_score +  4;
		END IF;



		-- Semi-Final
		SET @S1 := ( select semi_1 from `second_stage` where `id_poll` =idpool);
		SET @S2 := ( select semi_2 from `second_stage` where `id_poll` =idpool);
		SET @S3 := ( select semi_3 from `second_stage` where `id_poll` =idpool);
		SET @S4 := ( select semi_4 from `second_stage` where `id_poll` =idpool);
		SET @AS1 := ( select semi_1 from `second_stage` where `id_poll` =504);

		IF @S1 = @AS1 OR @S2 = @AS1 OR @S3 = @AS1 OR @S4 = @AS1 THEN
			SET cont_score = cont_score +  4;
			SET bonus_Semi =  bonus_Semi + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		
		SET @AS2 := ( select semi_2 from `second_stage` where `id_poll` =504);

		IF @S1 = @AS2 OR @S2 = @AS2 OR @S3 = @AS2 OR @S4 = @AS2 THEN
			SET cont_score = cont_score +  4;
			SET bonus_Semi =  bonus_Semi + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		
		SET @AS3 := ( select semi_3 from `second_stage` where `id_poll` =504);

		IF @S1 = @AS3 OR @S2 = @AS3 OR @S3 = @AS3 OR @S4 = @AS3 THEN
			SET cont_score = cont_score +  4;
			SET bonus_Semi =  bonus_Semi + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		
		SET @AS4 := ( select semi_4 from `second_stage` where `id_poll` =504);

		IF @S1 = @AS4 OR @S2 = @AS4 OR @S3 = @AS4 OR @S4 = @AS4 THEN
			SET cont_score = cont_score +  4;
			SET bonus_Semi =  bonus_Semi + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		-- BONUS Semi-Final 
		If bonus_Semi = 4 THEN
			SET cont_score = cont_score +  4;
		END IF;



		-- FINAL
		SET @F1 := ( select final_1 from `second_stage` where `id_poll` =idpool);
		SET @F2 := ( select final_2 from `second_stage` where `id_poll` =idpool);
		SET @AF1 := ( select final_1 from `second_stage` where `id_poll` =504);

		IF @F1 = @AF1 OR @F2 = @AF1 THEN
			SET cont_score = cont_score +  8;
			SET bonus_Final =  bonus_Final + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		
		SET @AF2 := ( select final_2 from `second_stage` where `id_poll` =504);

		IF @F1 = @AF2 OR @F2 = @AF2 THEN
			SET cont_score = cont_score +  8;
			SET bonus_Final =  bonus_Final + 1;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

		-- BONUS Semi-Final 
		If bonus_Final = 2 THEN
			SET cont_score = cont_score +  4;
		END IF;


		-- CHAMPION
		SET @C1 := ( select winner from `second_stage` where `id_poll` =idpool);
		SET @AC1 := ( select winner from `second_stage` where `id_poll` =504);

		IF @C1 = @AC1 THEN
			SET cont_score = cont_score +  20;
		ELSE
			SET cont_score = cont_score + 0;
		END IF;

        
        UPDATE user_poll SET score = cont_score WHERE iduser_poll = idpool;
  	  
      
		

  END LOOP bucle;
 
  CLOSE cursor_score;
  
  /* Llama procedimiento que genera el ranking*/
  -- Borra tabla de Ranking
  	TRUNCATE `ranking_pools`;
    
     CALL ranking();

END