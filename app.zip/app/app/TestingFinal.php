<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TestingFinal extends Model
{
    protected $table = 'testingfinal';

	public $timestamps = false;

}
